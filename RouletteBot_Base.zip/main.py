import telebot
from telebot import types
import pymongo
import os

# ========================
# CONFIGURATION VARIABLES
# ========================
BOT_TOKEN = os.getenv("BOT_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID", "0"))
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME")
MONGODB_URI = os.getenv("MONGODB_URI")
DRAW_CHANNEL = os.getenv("DRAW_CHANNEL")  # e.g. @Hikam_Gold

bot = telebot.TeleBot(BOT_TOKEN)
mongo = pymongo.MongoClient(MONGODB_URI)
db = mongo["roulette_bot"]

# ========================
# START COMMAND
# ========================
@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.from_user.id
    bot.send_message(
        message.chat.id,
        "👋 أهلاً بيك في روليت النور!
اضغط على /menu لفتح القائمة."
    )

@bot.message_handler(commands=['menu'])
def menu(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("🎁 صناديق الهدايا", "🎲 الروليت")
    markup.add("💰 رصيدي", "📨 الدعم الفني")
    bot.send_message(
        message.chat.id,
        "اختر من القائمة:", 
        reply_markup=markup
    )

# ========================
# SUPPORT
# ========================
@bot.message_handler(func=lambda m: m.text == "📨 الدعم الفني")
def support(message):
    bot.send_message(message.chat.id, f"تواصل مع الدعم:
@{SUPPORT_USERNAME}")

# ========================
# BOT RUN
# ========================
print("Bot running...")
bot.infinity_polling()
